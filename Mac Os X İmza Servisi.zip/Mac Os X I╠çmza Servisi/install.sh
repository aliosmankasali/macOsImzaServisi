#!/bin/bash
sudo cp -r TurksatImzaServis /Library
sudo cp -f /Library/TurksatImzaServis/tr.com.turksat.singNativeOsService.plist /Library/LaunchDaemons/tr.com.turksat.singNativeOsService.plist
sudo launchctl load /Library/LaunchDaemons/tr.com.turksat.singNativeOsService.plist
sudo launchctl start singNativeOsService
