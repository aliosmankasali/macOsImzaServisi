#!/bin/bash
sudo launchctl stop singNativeOsService