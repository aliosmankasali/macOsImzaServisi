#!/bin/bash
sudo launchctl stop   singNativeOsService
sudo launchctl unload /Library/LaunchDaemons/tr.com.turksat.singNativeOsService.plist
sudo rm /Library/LaunchDaemons/tr.com.turksat.singNativeOsService.plist
cd /
sudo rm -rf /Library/TurksatImzaServis
sudo rm -rf /tmp/TurksatImzaServis