#!/bin/bash
sudo launchctl start singNativeOsService